'use strict';
const root = $('#root');
let me = null;
window.onUnauth = () => { if (me) { me = null; toast('Your session has ended. Please sign in again.', 'err'); route(); } };
const NAV = [['home', 'Home', 'home'], ['attendance', 'Attendance', 'clock'], ['leave', 'Leave', 'calendar'], ['report', 'Daily report', 'doc'], ['payroll', 'Payroll', 'wallet'], ['profile', 'Profile', 'user']];

async function boot() { try { me = (await api('/api/me')).user; } catch { me = null; } route(); }
window.addEventListener('hashchange', route);
function route() {
  if (!me) return authView();
  const p = location.hash.replace('#/', '') || 'home', page = pages[p] ? p : 'home';
  put(root, h`<div class="app">
    <nav class="nav" aria-label="Main">${logo()}
      ${NAV.map(([k, l, i]) => h`<a class="nav-i ${k === page ? 'on' : ''}" href="#/${k}">${ico(i)}<span>${l}</span></a>`)}
      <div class="nav-foot"><b>${me.full_name}</b>${me.title}</div></nav>
    <main class="main" id="view"><div class="loading">Loading…</div></main></div>`);
  pages[page]($('#view')).catch(e => put($('#view'), h`<div class="note bad">${e.message}</div>`));
}
const head = (t, s) => h`<div class="top"><div><h1>${t}</h1><p>${s}</p></div></div>`;

/* ---------------- Auth ---------------- */
function authView(mode = 'login') {
  put(root, h`<div class="auth"><section class="auth-l">${logo()}
      <div><h1>Her work. Her pay. Her records — in one place.</h1><p>Sign in to mark attendance, request leave, send your daily report and sign your payroll.</p></div>
      <small>© WEDA · Women Empowerment Development Alliance</small></section>
    <section class="auth-r"><div class="auth-card">
      <div class="tabs"><button class="${mode === 'login' ? 'on' : ''}" data-m="login">Sign in</button><button class="${mode === 'register' ? 'on' : ''}" data-m="register">Create account</button></div>
      ${mode === 'login' ? h`<h2>Welcome back</h2><p class="sub">Use the phone number you registered with.</p>
      <form id="f"><div class="field"><label for="phone">Phone number</label><input id="phone" name="phone" type="tel" inputmode="tel" autocomplete="username" placeholder="+255 712 345 678" required></div>
        <div class="field"><label for="pw">Password</label><input id="pw" name="password" type="password" autocomplete="current-password" required></div>
        <button class="btn block" type="submit">Sign in</button></form>`
      : h`<h2>Join the team app</h2><p class="sub">Fill in your details. An admin will approve your account before you can sign in.</p>
      <form id="f"><div class="field"><label for="n">Full name</label><input id="n" name="full_name" autocomplete="name" required minlength="3" maxlength="80"></div>
        <div class="field"><label for="t">Title / position</label><input id="t" name="title" required minlength="2" maxlength="80" placeholder="e.g. Program Officer"></div>
        <div class="field"><label for="ph">Phone number</label><input id="ph" name="phone" type="tel" inputmode="tel" required placeholder="+255 712 345 678"><span class="hint">Use a number that receives normal text messages.</span></div>
        <div class="two"><div class="field"><label for="p1">Password</label><input id="p1" name="password" type="password" autocomplete="new-password" required minlength="8"></div>
        <div class="field"><label for="p2">Confirm</label><input id="p2" name="confirm" type="password" autocomplete="new-password" required></div></div>
        <p class="hint mt2" style="margin-bottom:12px">At least 8 characters with letters and numbers.</p>
        <button class="btn block" type="submit">Send for approval</button></form>`}
    </div></section></div>`);
  $$('.tabs button').forEach(b => b.onclick = () => authView(b.dataset.m));
  $('#f').onsubmit = e => { e.preventDefault(); const btn = $('button[type=submit]', e.target);
    busy(btn, async () => {
      if (mode === 'login') { me = (await api('/api/login', { method: 'POST', body: form(e.target) })).user; location.hash = '#/home'; route(); }
      else { await api('/api/register', { method: 'POST', body: form(e.target) }); authView('login'); toast('Account created. You can sign in once an admin approves it.', 'ok'); }
    }); };
}

const pages = {};
/* ---------------- Home ---------------- */
pages.home = async el => {
  const [t, hist, pay] = await Promise.all([api('/api/attendance/today'), api('/api/attendance/history'), api('/api/payroll')]);
  const r = t.record, s = hist.summary, unsigned = pay.items.filter(i => i.status === 'pending').length;
  const blocked = t.weekend ? 'Weekend — enjoy your rest.' : t.holiday ? 'Public holiday: ' + t.holiday : t.leave ? 'You are on ' + t.leave + ' leave today.' : '';
  const state = r && r.check_out ? 'done' : r ? 'out' : 'in';
  put(el, h`<div class="hero"><div class="row sp"><div><p>${fmtDate(t.date)}</p><h2>Hello, ${me.full_name.split(' ')[0]}</h2><p>${me.title}</p></div></div></div>
  <div class="grid split mt">
    <div class="card"><h3>Attendance</h3><p class="sub">You can only sign when you are inside an office zone.</p>
      <div class="clock">${blocked ? h`<div class="note">${blocked}</div>` : h`<button class="pulse ${state === 'in' ? '' : state}" id="go" ${state === 'done' ? 'disabled' : ''}>${ico(state === 'in' ? 'pin' : state === 'out' ? 'out' : 'check')}${state === 'in' ? 'Sign in' : state === 'out' ? 'Sign out' : 'Done'}</button>`}</div>
      <div class="row sp mt"><span class="mut small">In: <b>${fmtTime(r && r.check_in)}</b></span><span class="mut small">Out: <b>${fmtTime(r && r.check_out)}</b></span><span class="mut small">${t.offices.length ? t.offices.map(o => o.name + ' (' + o.radius_m + ' m)').join(', ') : 'No office set up yet'}</span></div>
      <p class="small mt2 note bad" id="gerr" hidden></p></div>
    <div class="grid" style="align-content:start">
      ${unsigned ? h`<a class="card pay" href="#/payroll" style="text-decoration:none;color:inherit"><b>${unsigned} payroll${unsigned > 1 ? 's' : ''} waiting for your signature</b><p class="mut small">Tap to review and sign.</p></a>` : ''}
      <div class="card"><h3>${fmtMonth(hist.month)}</h3><p class="sub">Your month so far</p>
        <div class="grid g2" style="gap:10px"><div class="stat ok" style="padding:6px 0"><div class="ic">${ico('check')}</div><div><b>${s.present}</b><span>Present</span></div></div>
        <div class="stat gold" style="padding:6px 0"><div class="ic">${ico('calendar')}</div><div><b>${s.leave}</b><span>On leave</span></div></div>
        <div class="stat coral" style="padding:6px 0"><div class="ic">${ico('clock')}</div><div><b>${s.absent}</b><span>Absent</span></div></div>
        <div class="stat" style="padding:6px 0"><div class="ic">${ico('list')}</div><div><b>${s.workingDays}</b><span>Working days</span></div></div></div></div>
      <a class="btn gold" href="#/report">Write today's report</a></div></div>`);
  const go = $('#go');
  if (go) go.onclick = () => busy(go, async () => {
    const g = $('#gerr'); g.hidden = true;
    try {
      const pos = await new Promise((ok, no) => navigator.geolocation ? navigator.geolocation.getCurrentPosition(ok, no, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }) : no({ code: 0 }));
      await api('/api/attendance/' + (state === 'in' ? 'checkin' : 'checkout'), { method: 'POST', body: { lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy } });
      toast(state === 'in' ? 'Signed in. Have a great day!' : 'Signed out. See you tomorrow!', 'ok'); pages.home(el);
    } catch (e) {
      g.textContent = e.code === 1 ? 'Location permission is blocked. Allow location for this app in your browser settings.' : e.code ? 'Could not get your location. Turn on GPS and try again.' : e.message; g.hidden = false; throw new Error(g.textContent);
    }
  });
};

/* ---------------- Attendance ---------------- */
pages.attendance = async el => {
  const month = (location.hash.split('?m=')[1]) || thisMonth();
  const d = await api('/api/attendance/history?month=' + month), s = d.summary;
  put(el, h`${head('Attendance', 'Weekends and public holidays are not counted.')}
  <div class="row mt2" style="margin-bottom:16px"><div class="field" style="margin:0"><label for="m">Month</label><input id="m" type="month" value="${d.month}"></div></div>
  <div class="grid g4"><div class="card stat ok"><div class="ic">${ico('check')}</div><div><b>${s.present}</b><span>Days present</span></div></div>
    <div class="card stat gold"><div class="ic">${ico('calendar')}</div><div><b>${s.leave}</b><span>Leave days</span></div></div>
    <div class="card stat coral"><div class="ic">${ico('clock')}</div><div><b>${s.absent}</b><span>Days absent</span></div></div>
    <div class="card stat"><div class="ic">${ico('list')}</div><div><b>${s.workingDays}</b><span>Working days</span></div></div></div>
  <div class="mt">${d.rows.length ? h`<div class="tw"><table><thead><tr><th>Date</th><th>Signed in</th><th>Signed out</th><th>Distance at sign-in</th></tr></thead><tbody>
    ${d.rows.map(r => h`<tr><td>${fmtDate(r.date)}</td><td>${fmtTime(r.check_in)}</td><td>${fmtTime(r.check_out)}</td><td>${r.in_distance} m</td></tr>`)}</tbody></table></div>` : h`<div class="card empty">No attendance recorded for this month.</div>`}</div>`);
  $('#m').onchange = e => { location.hash = '#/attendance?m=' + e.target.value; };
};

/* ---------------- Leave ---------------- */
pages.leave = async el => {
  const [d, hol] = await Promise.all([api('/api/leaves'), api('/api/holidays')]);
  put(el, h`${head('Leave', 'Choose your dates. HR reviews every request.')}
  <div class="grid g2"><div class="card"><h3>New request</h3><p class="sub">Weekends and public holidays are excluded automatically.</p>
    <form id="lf"><div class="field"><label for="ty">Leave type</label><select id="ty" name="type">${d.types.map(t => h`<option>${t}</option>`)}</select></div>
    <div class="two"><div class="field"><label for="s">From</label><input id="s" name="start" type="date" min="${todayISO()}" required></div><div class="field"><label for="e">To</label><input id="e" name="end" type="date" min="${todayISO()}" required></div></div>
    <div class="note" id="calc" hidden></div>
    <div class="field mt2"><label for="r">Reason <span class="mut">(optional)</span></label><textarea id="r" name="reason" maxlength="600"></textarea></div>
    <button class="btn block" type="submit">Send request</button></form></div>
    <div class="card"><h3>Upcoming public holidays</h3><p class="sub">These days do not count as leave.</p>
      ${hol.holidays.length ? h`<dl class="kv">${hol.holidays.slice(0, 8).map(x => h`<dt>${fmtDate(x.date)}</dt><dd>${x.name}</dd>`)}</dl>` : h`<div class="empty">No holidays registered.</div>`}</div></div>
  <h3 class="mt">My requests</h3>
  <div class="mt2">${d.leaves.length ? h`<div class="tw"><table><thead><tr><th>Type</th><th>Dates</th><th>Days</th><th>Status</th><th>HR note</th><th></th></tr></thead><tbody>
    ${d.leaves.map(l => h`<tr><td>${l.type}</td><td class="nowrap">${fmtDate(l.start_date)}${l.end_date !== l.start_date ? h` → ${fmtDate(l.end_date)}` : ''}</td><td>${l.days}</td><td>${badge(l.status)}</td><td>${l.review_note || '—'}</td>
    <td>${l.status === 'pending' ? h`<button class="btn sm ghost" data-c="${l.id}">Cancel</button>` : ''}</td></tr>`)}</tbody></table></div>` : h`<div class="card empty">You have not requested any leave yet.</div>`}</div>`);
  const calc = async () => {
    const s = $('#s').value, e = $('#e').value, c = $('#calc'); if (!s || !e) return;
    try { const r = await api(`/api/leaves/calc?start=${s}&end=${e}`); c.hidden = false; c.className = 'note ok';
      put(c, h`<b>${r.working} working day${r.working === 1 ? '' : 's'}</b> will be deducted. Excluded: ${r.weekends} weekend day${r.weekends === 1 ? '' : 's'}${r.holidays.length ? h`, holiday${r.holidays.length > 1 ? 's' : ''}: ${r.holidays.map(x => x.name).join(', ')}` : ''}.`);
    } catch (x) { c.hidden = false; c.className = 'note bad'; c.textContent = x.message; }
  };
  $('#s').onchange = () => { if (!$('#e').value || $('#e').value < $('#s').value) $('#e').value = $('#s').value; $('#e').min = $('#s').value; calc(); }; $('#e').onchange = calc;
  $('#lf').onsubmit = ev => { ev.preventDefault(); busy($('button[type=submit]', ev.target), async () => { const r = await api('/api/leaves', { method: 'POST', body: form(ev.target) }); toast(`Request sent for ${r.days} working day${r.days === 1 ? '' : 's'}.`, 'ok'); pages.leave(el); }); };
  $$('[data-c]', el).forEach(b => b.onclick = () => busy(b, async () => { await api(`/api/leaves/${b.dataset.c}/cancel`, { method: 'POST', body: {} }); toast('Request cancelled.'); pages.leave(el); }));
};

/* ---------------- Daily report ---------------- */
pages.report = async el => {
  const d = await api('/api/reports'), t = d.reports.find(r => r.date === d.today) || {};
  put(el, h`${head('Daily report', fmtDate(d.today))}
  <div class="grid split"><div class="card"><h3>${t.work_done ? "Today's report (editable until midnight)" : "Today's report"}</h3><p class="sub">Be specific — your supervisor reads this.</p>
    <form id="rf"><div class="field"><label for="w">What did you work on today?</label><textarea id="w" name="work_done" required minlength="10" maxlength="4000">${t.work_done || ''}</textarea></div>
    <div class="field"><label for="c">Challenges you faced</label><textarea id="c" name="challenges" maxlength="3000">${t.challenges || ''}</textarea></div>
    <div class="field"><label for="g">Suggestions</label><textarea id="g" name="suggestions" maxlength="3000">${t.suggestions || ''}</textarea></div>
    <button class="btn block" type="submit">${t.work_done ? 'Update report' : 'Submit report'}</button></form></div>
    <div class="card"><h3>Previous reports</h3><p class="sub">Your last ${Math.min(d.reports.length, 60)} reports</p>
      ${d.reports.length ? d.reports.map(r => h`<details style="border-top:1px solid var(--line);padding:10px 0"><summary style="cursor:pointer;font-weight:600">${fmtDate(r.date)}</summary>
        <p class="small mt2"><b>Work done</b><br>${r.work_done}</p>${r.challenges ? h`<p class="small mt2"><b>Challenges</b><br>${r.challenges}</p>` : ''}${r.suggestions ? h`<p class="small mt2"><b>Suggestions</b><br>${r.suggestions}</p>` : ''}</details>`) : h`<div class="empty">Nothing yet. Your first report starts here.</div>`}</div></div>`);
  $$('details p', el).forEach(p => p.style.whiteSpace = 'pre-wrap');
  $('#rf').onsubmit = ev => { ev.preventDefault(); busy($('button[type=submit]', ev.target), async () => { await api('/api/reports', { method: 'POST', body: form(ev.target) }); toast('Report saved.', 'ok'); pages.report(el); }); };
};

/* ---------------- Payroll ---------------- */
let payTab = 'summary';
pages.payroll = async el => {
  const { items } = await api('/api/payroll');
  put(el, h`${head('Payroll', 'Review your salary, then sign to confirm you will receive it.')}
  <div class="tabs"><button class="${payTab === 'summary' ? 'on' : ''}" data-t="summary">Salary summary</button><button class="${payTab === 'pay' ? 'on' : ''}" data-t="pay">Amount to be paid ${items.some(i => i.status === 'pending') ? '•' : ''}</button></div>
  ${!items.length ? h`<div class="card empty">No payroll has been released to you yet. HR will publish it here.</div>` : payTab === 'summary'
    ? h`<div class="tw"><table><thead><tr><th>Name</th><th>Salary month</th><th class="right">Total salary</th></tr></thead><tbody>${items.map(i => h`<tr><td><b>${me.full_name}</b><div class="mut small">${me.title}</div></td><td>${fmtMonth(i.month)}</td><td class="right"><b>${money(i.total_salary)}</b></td></tr>`)}</tbody></table></div>`
    : h`<div class="grid g2">${items.map(i => h`<div class="card pay"><div class="row sp"><b>${fmtMonth(i.month)}</b>${badge(i.status === 'pending' ? 'pending' : i.status)}</div>
        <p class="mut small mt2">Amount to be paid</p><div class="amt">${money(i.net_pay)}</div>
        <dl class="kv mt2"><dt>Total salary</dt><dd>${money(i.total_salary)}</dd><dt>Deductions</dt><dd>− ${money(i.deductions)}</dd></dl>
        <div class="mt">${i.status === 'pending' ? h`<button class="btn gold block" data-s="${i.id}" data-m="${i.month}" data-a="${i.net_pay}">Sign to receive payment</button>`
          : i.status === 'signed' ? h`<div class="note">Signed on ${fmtStamp(i.signed_at)}. HR will pay you and mark it as paid.</div>`
          : h`<div class="note ok">Paid on ${fmtStamp(i.paid_at)}${i.payment_method ? ' via ' + i.payment_method : ''}${i.payment_ref ? ' · Ref ' + i.payment_ref : ''}</div>`}</div></div>`)}</div>`}`);
  $$('.tabs button', el).forEach(b => b.onclick = () => { payTab = b.dataset.t; pages.payroll(el); });
  $$('[data-s]', el).forEach(b => b.onclick = () => modal('Sign payroll', h`<p>I, <b>${me.full_name}</b>, confirm that I am due <b>${money(b.dataset.a)}</b> for <b>${fmtMonth(b.dataset.m)}</b> and will receive it from HR.</p>
    <form id="sg" class="mt"><div class="field"><label for="sp">Enter your password to sign</label><input id="sp" name="password" type="password" autocomplete="current-password" required></div>
    <button class="btn gold block" type="submit">Sign now</button></form>`, o => {
    $('#sg', o).onsubmit = ev => { ev.preventDefault(); busy($('button', ev.target), async () => { await api(`/api/payroll/${b.dataset.s}/sign`, { method: 'POST', body: form(ev.target) }); o.remove(); toast('Signed. HR has been notified.', 'ok'); pages.payroll(el); }); };
  }));
};

/* ---------------- Profile ---------------- */
pages.profile = async el => {
  put(el, h`${head('Profile', 'Your account details and security.')}
  <div class="grid g2"><div class="card"><h3>${me.full_name}</h3><p class="sub">${me.title}</p><dl class="kv"><dt>Phone</dt><dd>${me.phone}</dd><dt>Account</dt><dd>Employee</dd></dl>
    <button class="btn ghost mt" id="lo">${ico('logout')} Sign out</button></div>
    <div class="card"><h3>Change password</h3><p class="sub">Use letters and numbers, at least 8 characters.</p>
    <form id="pf"><div class="field"><label for="a">Current password</label><input id="a" name="current" type="password" autocomplete="current-password" required></div>
    <div class="field"><label for="b">New password</label><input id="b" name="password" type="password" autocomplete="new-password" required minlength="8"></div>
    <button class="btn block" type="submit">Save password</button></form></div></div>`);
  $('#lo').onclick = async () => { await api('/api/logout', { method: 'POST', body: {} }).catch(() => {}); me = null; location.hash = ''; route(); };
  $('#pf').onsubmit = ev => { ev.preventDefault(); busy($('button', ev.target), async () => { await api('/api/change-password', { method: 'POST', body: form(ev.target) }); ev.target.reset(); toast('Password updated.', 'ok'); }); };
};
boot();
